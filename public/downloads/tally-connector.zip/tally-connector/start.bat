@echo off
title DMS Tally Connector
cd /d "%~dp0"

if not exist "config.json" (
  echo Creating config.json from example...
  copy /Y config.example.json config.json >nul
  echo.
  echo EDIT config.json now:
  echo   - connector_token  (from your DMS admin)
  echo   - tally_url        (usually http://127.0.0.1:9000)
  echo   - company          (exact Tally company name, optional)
  echo.
  notepad config.json
  pause
)

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18+ is required.
  echo Download: https://nodejs.org/
  pause
  exit /b 1
)

echo Starting connector... Keep this window open while Tally is running.
node connector.mjs
pause
